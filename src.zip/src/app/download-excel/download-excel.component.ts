import { Component } from '@angular/core';

@Component({
  selector: 'app-download-excel',
  imports: [],
  templateUrl: './download-excel.component.html',
  styleUrl: './download-excel.component.css'
})
export class DownloadExcelComponent {

}
