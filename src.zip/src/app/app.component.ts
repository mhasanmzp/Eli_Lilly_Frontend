import { Component } from '@angular/core';
import * as XLSX from 'xlsx';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule
  ],
  templateUrl: './app.component.html',
})
// export class AppComponent {
//   excelData: any[] = [];
//   headers: string[] = [];
//   message: string = '';
//   success: boolean = false;

//   exactMatches: any[] = [];
//   partialMatches: any[] = [];
//   duplicateRecords: any[] = []; // To hold duplicate records
//   potentialMatches: any[] = []; // To hold potential matches from API
//   uniqueRecords: any[] = [];

//   constructor(private http: HttpClient) {}

//   // Handle file upload and parse it as Excel data
//   onFileChange(event: any) {
//     const target: DataTransfer = <DataTransfer>event.target;
//     if (target.files.length !== 1) return;

//     const reader: FileReader = new FileReader();
//     reader.onload = (e: any) => {
//       const binaryStr: string = e.target.result;
//       const wb: XLSX.WorkBook = XLSX.read(binaryStr, { type: 'binary' });
//       const wsName: string = wb.SheetNames[0];
//       const ws: XLSX.WorkSheet = wb.Sheets[wsName];
//       const data = XLSX.utils.sheet_to_json(ws) as any[];
//       this.excelData = data;
//       this.headers = data.length > 0 ? Object.keys(data[0]) : [];
//       this.message = '';
//       this.success = false;

//       // Reset the tables when a new file is uploaded
//       this.exactMatches = [];
//       this.partialMatches = [];
//       this.uniqueRecords = [];
//       this.duplicateRecords = [];
//       this.potentialMatches = [];
//     };
//     reader.readAsBinaryString(target.files[0]);
//   }

//   // Validate data by calling the backend API
//   validateData() {
//     this.http.post<any>('http://localhost:5000/validate-data', {
//       records: this.excelData,
//     }).subscribe(
//       res => {
//         this.exactMatches = res.exactMatches || [];
//         this.partialMatches = res.partialMatches || [];
//         this.uniqueRecords = res.uniqueRecords || [];
//         this.duplicateRecords = res.duplicates || [];
//         this.potentialMatches = res.potentialMatches || []; // Ensure potential matches are set correctly
//         this.message = res.success ? 'Validation completed.' : 'Validation failed.';
//         this.success = res.success;
//       },
//       err => {
//         this.message = 'Validation failed.';
//         this.success = false;
//       }
//     );
//   }

//   // Save unique records to the backend
//   saveUniqueData() {
//     this.http.post<any>('http://localhost:5000/save-unique', {
//       records: this.uniqueRecords,
//     }).subscribe(
//       res => {
//         this.message = res.message || 'Unique records saved.';
//         this.success = true;
//         this.exactMatches = [];
//         this.partialMatches = [];
//         this.uniqueRecords = [];
//         this.duplicateRecords = [];
//         this.potentialMatches = [];
//         this.excelData = [];
//       },
//       err => {
//         this.message = 'Failed to save records.';
//         this.success = false;
//       }
//     );
//   }

//   // Helper function to get match information for a specific field
//   getMatchInfo(
//     matchedFields: { field: string; matchedValue: string; percentage: number }[],
//     key: string
//   ) {
//     return matchedFields?.find(field => field.field === key);
//   }
// }



















// import { Component } from '@angular/core';
// import * as XLSX from 'xlsx';
// import { HttpClient, HttpClientModule } from '@angular/common/http';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-root',
//   standalone: true,
//   imports: [CommonModule, HttpClientModule],
//   templateUrl: './app.component.html',
// })
// export class AppComponent {
//   excelData: any[] = [];
//   headers: string[] = [];
//   message: string = '';
//   success: boolean = false;

//   duplicateRecords: {
//     row: any;
//     matchedFields: {
//       field: string;
//       matchedValue: string;
//       percentage: number;
//     }[];
//   }[] = [];

//   constructor(private http: HttpClient) {}

//   onFileChange(event: any) {
//     const target: DataTransfer = <DataTransfer>event.target;
//     if (target.files.length !== 1) return;

//     const reader: FileReader = new FileReader();
//     reader.onload = (e: any) => {
//       const binaryStr: string = e.target.result;
//       const wb: XLSX.WorkBook = XLSX.read(binaryStr, { type: 'binary' });
//       const wsName: string = wb.SheetNames[0];
//       const ws: XLSX.WorkSheet = wb.Sheets[wsName];
//       const data = XLSX.utils.sheet_to_json(ws) as any[];
//       this.excelData = data;
//       this.headers = data.length > 0 ? Object.keys(data[0]) : [];
//       this.message = '';
//       this.duplicateRecords = [];
//     };
//     reader.readAsBinaryString(target.files[0]);
//   }

//   uploadToServer() {
//     this.http
//       .post('http://localhost:5000/check-and-save', {
//         records: this.excelData,
//       })
//       .subscribe(
//         (res: any) => {
//           if (!res.success && res.duplicates) {
//             this.duplicateRecords = res.duplicates;
//             this.message = res.message;
//             this.success = false;
//           } else {
//             this.message = res.message;
//             this.success = true;
//             this.duplicateRecords = [];
//             this.excelData = [];
//           }
//         },
//         (error) => {
//           this.message = 'Error uploading file.';
//           this.success = false;
//         }
//       );
//   }

//   // Helper to get match info for a field
//   getMatchInfo(
//     matchedFields: { field: string; matchedValue: string; percentage: number }[],
//     key: string
//   ) {
//     return matchedFields.find((field) => field.field === key);
//   }

//   // Optional: Helper to get color class (if you prefer CSS classes over inline style)
//   getColorByPercentage(percentage: number): string {
//     if (percentage === 100) return 'red';
//     if (percentage > 0) return 'orange';
//     return 'green';
//   }

//   getMatchColor(field: string, percentage: number): string {
//     const exactFields = ["Email_Address", "Country_Region", "Bank_Account_No"];
//     const fuzzyFields = [
//       "Vendor_Name 1", "Name 2", "Name 3", 
//       "Address", "Street", "City_Name", "Region"
//     ];
  
//     if (exactFields.includes(field)) {
//       return percentage === 100 ? "red" : "green";
//     }
  
//     if (fuzzyFields.includes(field)) {
//       if (percentage >= 80) return "orange";
//       return "green";
//     }
  
//     return "green";
//   }
  
// }
export class AppComponent {
  excelData: any[] = [];
  headers: string[] = [];
  message: string = '';
  success: boolean = false;

  exactMatches: any[] = [];
  partialMatches: any[] = [];
  duplicateRecords: any[] = [];
  potentialMatches: any[] = [];
  uniqueRecords: any[] = [];
  

  // Section toggle states
  showPreviewTable = true;
  showDuplicatesTable = true;
  showPotentialTable = true;
  showUniqueTable = true;
  

  constructor(private http: HttpClient) {}

  onFileChange(event: any) {
    const target: DataTransfer = <DataTransfer>event.target;
    if (target.files.length !== 1) return;

    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const binaryStr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(binaryStr, { type: 'binary' });
      const wsName: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsName];
      const data = XLSX.utils.sheet_to_json(ws) as any[];
      this.excelData = data;
      this.headers = data.length > 0 ? Object.keys(data[0]) : [];
      this.message = '';
      this.success = false;

      // Clear existing matches
      this.exactMatches = [];
      this.partialMatches = [];
      this.uniqueRecords = [];
      this.duplicateRecords = [];
      this.potentialMatches = [];
    };
    reader.readAsBinaryString(target.files[0]);
  }

  selectAllPotential = false;
selectAllUnique = false;

toggleSelectAll(type: 'potential' | 'unique') {
  const list = type === 'potential' ? this.potentialMatches : this.uniqueRecords;
  const flag = type === 'potential' ? this.selectAllPotential : this.selectAllUnique;

  list.forEach(record => record.selected = flag);
}


  validateData() {
    // this.http.post<any>('http://localhost:5000/validate-data', {
      this.http.post<any>('http://localhost:5000/fetch-and-validate', {

      records: this.excelData,
    }).subscribe(
      res => {
        this.exactMatches = res.exactMatches || [];
        this.partialMatches = res.partialMatches || [];
        this.uniqueRecords = res.uniqueRecords || [];
        this.duplicateRecords = res.duplicates || [];
        this.potentialMatches = res.potentialMatches || [];
        this.message = res.success ? 'Validation completed.' : 'Validation failed.';
        this.success = res.success;

        // Show section after validation
        this.showUniqueTable = true;

      },
      err => {
        this.message = 'Validation failed.';
        this.success = false;
      }
    );
  }
  

  saveUniqueData() {
    this.http.post<any>('http://localhost:5000/save-unique', {
      records: this.uniqueRecords,
    }).subscribe(
      res => {
        this.message = res.message || 'Unique records saved.';
        this.success = true;
        this.exactMatches = [];
        this.partialMatches = [];
        this.uniqueRecords = [];
        this.duplicateRecords = [];
        this.potentialMatches = [];
        this.excelData = [];
      },
      err => {
        this.message = 'Failed to save records.';
        this.success = false;
      }
    );
  }

  getMatchInfo(
    matchedFields: { field: string; matchedValue: string; percentage: number }[],
    key: string
  ) {
    return matchedFields?.find(field => field.field === key);
  }

  toggleSection(section: string) {
    switch (section) {
      case 'preview':
        this.showPreviewTable = !this.showPreviewTable;
        break;
      case 'duplicates':
        this.showDuplicatesTable = !this.showDuplicatesTable;
        break;
      case 'potential':
        this.showPotentialTable = !this.showPotentialTable;
        break;
      case 'unique':
        this.showUniqueTable = !this.showUniqueTable;
        break;
    }
  }
}

